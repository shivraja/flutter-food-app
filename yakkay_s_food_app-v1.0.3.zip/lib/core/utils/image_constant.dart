class ImageConstant {
  static String imgNxmlubuz0b1qixa87x87 =
      'assets/images/img_nxmlubuz0b1qixa_87x87.png';

  static String imgSoppressatapiz = 'assets/images/img_soppressatapiz.png';

  static String imgGrid = 'assets/images/img_grid.svg';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgNxmlubuz0b1qixa = 'assets/images/img_nxmlubuz0b1qixa.png';

  static String imgTopviewpanwi = 'assets/images/img_topviewpanwi.png';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgGirl = 'assets/images/img_girl.png';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgThumbsup2 = 'assets/images/img_thumbsup2.svg';

  static String imgLike = 'assets/images/img_like.svg';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgCameraicon = 'assets/images/img_cameraicon.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgAshread1 = 'assets/images/img_ashread1.png';

  static String imgDumalooe16363 = 'assets/images/img_dumalooe16363.png';

  static String imgEllipse2 = 'assets/images/img_ellipse2.png';

  static String imgThumbsup = 'assets/images/img_thumbsup.svg';

  static String img1000f42640874 = 'assets/images/img_1000f42640874.png';

  static String img197987b7ebcd1ee = 'assets/images/img_197987b7ebcd1ee.png';

  static String imgFennelroasted = 'assets/images/img_fennelroasted.png';

  static String imgGroup28 = 'assets/images/img_group28.png';

  static String imgFlatlaypakist = 'assets/images/img_flatlaypakist.png';

  static String imgGroup27 = 'assets/images/img_group27.svg';

  static String imgIcons8star961 = 'assets/images/img_icons8star961.png';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgCamera = 'assets/images/img_camera.svg';

  static String imgFavorite = 'assets/images/img_favorite.svg';

  static String imgShrimpfriedri = 'assets/images/img_shrimpfriedri.png';

  static String imgIcons8save902 = 'assets/images/img_icons8save902.png';

  static String imgIcons8star963 = 'assets/images/img_icons8star963.png';

  static String imgVectorBlue700 = 'assets/images/img_vector_blue_700.svg';

  static String imgPakistanifood = 'assets/images/img_pakistanifood.png';

  static String imgFennelroasted376x368 =
      'assets/images/img_fennelroasted_376x368.png';

  static String imgOverflowmenu = 'assets/images/img_overflowmenu.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
