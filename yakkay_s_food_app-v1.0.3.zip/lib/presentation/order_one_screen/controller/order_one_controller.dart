import 'package:yakkay_s_food_app/core/app_export.dart';
import 'package:yakkay_s_food_app/presentation/order_one_screen/models/order_one_model.dart';

class OrderOneController extends GetxController {
  Rx<OrderOneModel> orderOneModelObj = OrderOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
