class RateOneModel {}
