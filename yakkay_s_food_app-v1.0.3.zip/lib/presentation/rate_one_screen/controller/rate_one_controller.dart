import 'package:yakkay_s_food_app/core/app_export.dart';
import 'package:yakkay_s_food_app/presentation/rate_one_screen/models/rate_one_model.dart';

class RateOneController extends GetxController {
  Rx<RateOneModel> rateOneModelObj = RateOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
