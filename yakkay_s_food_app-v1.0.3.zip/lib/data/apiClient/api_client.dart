import 'package:yakkay_s_food_app/core/app_export.dart';

class ApiClient extends GetConnect {}
